# encoding: utf-8

# The version of logstash core event java gem.
#
# Note to authors: this should not include dashes because 'gem' barfs if
# you include a dash in the version string.

LOGSTASH_CORE_EVENT_JAVA_VERSION = "5.1.1"
